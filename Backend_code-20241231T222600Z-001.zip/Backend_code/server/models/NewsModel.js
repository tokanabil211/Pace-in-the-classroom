const mongoose = require("mongoose");

const NewsSchema = new mongoose.Schema({
  id: {
    type: Number,
  },
  title: {
    type: String,
    
    required: true,
  },
  url: {
    type: String,
  },
});

const NewsModel = mongoose.model("New", NewsSchema);

module.exports = NewsModel;
