const mongoose = require("mongoose");

const MapsSchema = new mongoose.Schema({
  id: {
    type: Number,
  },
  title: {
    type: String,
    
    required: true,
  },
  url: {
    type: String,
  },
});

const MapsModel = mongoose.model("Map", MapsSchema);

module.exports = MapsModel;
