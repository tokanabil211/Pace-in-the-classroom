require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const { getVideo, getAllVideos } = require("./controllers/VideosControllers");
const {
  getAllBrochures,
  getBrochure,
} = require("./controllers/BrochureControllers");

const { getDoc, getAllDocs } = require("./controllers/DocsControllers");
const { getAllNews, getNew } = require("./controllers/NewsControllers");
const { getAllMaps, getMap } = require("./controllers/MapsControllers");
const { getAllImages, getImage } = require("./controllers/ImageControllers");

const app = express();
const PORT = process.env.PORT || 3000;
const MONGO_URL = process.env.MONGO_URL;

// Middleware
app.use(express.json()); // This is necessary for parsing JSON request bodies
app.use(cors()); // Allow all origins. Change to specific origins as needed.

mongoose
  .connect(MONGO_URL)
  .then(() => console.log("Database Connected"))
  .catch((err) => console.error("Database Connection Error:", err));

app.get("/", (req, res) => {
  return res.status(200).json({ status: "success", message: "hello from server" });
});

// Define your routes here
// Videos
app.get("/api/v1/videos", getAllVideos);
app.get("/api/v1/videos/:id", getVideo);

// Brochures
app.get("/api/v1/brochures", getAllBrochures);
app.get("/api/v1/brochures/:id", getBrochure);


// Docs
app.get("/api/v1/docs", getAllDocs);
app.get("/api/v1/docs/:id", getDoc);

// News
app.get("/api/v1/news", getAllNews);
app.get("/api/v1/news/:id", getNew);

// Story Maps
app.get("/api/v1/maps", getAllMaps);
app.get("/api/v1/maps/:id", getMap);

// Images
app.get("/api/v1/images", getAllImages);
app.get("/api/v1/images/:id", getImage);

// Start the server
app.listen(PORT, () => console.log(`Server Running On Port ${PORT}`));
